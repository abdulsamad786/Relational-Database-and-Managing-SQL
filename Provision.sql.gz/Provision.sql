
mysql> Create database NamesInc;

mysql> Use NamesInc;

mysql> show tables;

mysql>create table Place( PlaceID int not null auto_increment,  Latitude Decimal(10,5), Longitude (10,5),Elevation varchar(50),Popula
tion Float, FeatureCode Varchar(6), Type Varchar(100), Country Varchar(100), Primary key (PlaceID)  )
 auto_increment = 1;

mysql> Create Table Info( InfoID int not null auto_increment, Name varchar(50), Language varchar(50), Status varchar(50),
 Standard varchar(50), SupplierID varchar(20), DateSupplied Date, Primary key (InfoID) )auto_increment=1;

mysql>Create table Supplier(SupplierID int not null auto_increment,Name varchar(50),Country varchar(50),ReliabilityScore Float,Contac
tInfo varchar(15), Primary Key(SupplierID) )auto_increment = 1;

mysql> Create Table Payement(  SupplierID int not null auto_increment,Date date, Amount Float,Primary Key(SupplierID))auto_increment
= 1;

mysql> Create Table Payement(  SupplierID int not null auto_increment,
    -> Date date,
    -> Amount Float,
    -> Primary Key(SupplierID),
        )auto_increment = 1;

mysql> Create table Department( DeptID int not null auto_increment, DeptName varchar(50), DeptHeadID varchar(10), DeptAA varchar(10),
 ParentDeptID
varchar(10), Primary Key (DeptID) )auto_increment = 1;

mysql>Create table Employees( EmpID int not null auto_increment, Name varchar(10), TaxID varchar(10), Country varchar(50), HireDate d
ate,  Birthdate date, Salary Decimal(10,2), Bonus Decimal(10,2), Primary Key(EmpID));

mysql> show tables;

mysql> insert into Place( PlaceID , Latitude , Longitude,Elevation,Population, FeatureCode, Type, Country) VALUES (1816671, 39.975415
84, 39.12458673,236, 1000000, 'BAY', 'Coast','USA'), (1899241, 83.98347851, 43.94752154, 250, 250000, "DOMG","Mountain", "USA"),  (10
99241, 57.98347851, 78.94752154, 280, 290000, "CUTF","Sea", "Germany");

mysql> insert into Info Values ( 123456789,"China","Chinese","exists","yes","123456789",'2000-12-01'), (324123456,"USA","English","ex
ists","yes","324567831",'2001-03-01'), (134563256,"Malaysia","Malay","exists","yes","456732134",'2003-02-09');

mysql> select * from Supplier;

mysql> select * from Employees;

mysql> insert into Employees
    -> Values(" 5276442", "Sam", "912-70-3456", "USA", "2000-01-24", "1988-01-24", 10000000, 125000),
    -> (" 5276542", "Julie", "913-72-3457", "USA", "2010-02-24", "1991-02-13", 1500000, 135000),
    -> (" 5475542", "Jamie", "923-52-3487", "USA", "2008-03-14", "1987-05-17", 1650000, 105000);

mysql> show warnings;

mysql> ALTER TABLE Employees MODIFY TaxID varchar(11);

mysql> select * from Employees;

mysql> ALTER TABLE Department Modify DeptAA varchar(50);

mysql> ALTER TABLE Department Modify ParentDeptID varchar(50);

mysql> Update Employees Set Bonus = 0;

mysql> INSERT INTO Department(DeptID, DeptName, DeptHeadID, DeptAA, ParentDeptID)
    -> Values( 200, 'Procurement', '201', 'sub-Marketing', 'Marketing'),
    -> (300, 'IT', '301', 'IT-Development', 'Reasearch And Development');

mysql> select * from Department;

mysql> show tables;

mysql> insert into Payement Values( 501, '2014-09-08', 1250000),
    -> (502, '2013-06-07', '2500000'),
    -> (503, '2012-08-06', '2750000');

mysql> select * from Payement;

mysql> ALter Table Place ADD Partial_Name Varchar(50);

mysql> select * from Place;

mysql> Update Place Set Partial_Name = 'FK' where Country = 'Germany';

mysql> Update Place Set Partial_Name = 'SFO' where Country = 'USA';

mysql> Update Place Set Partial_Name = 'NY' where Country = 'USA' and Type = 'Mountain';

mysql> select * from Place;

mysql> Select Latitude, Longitude From Place;

mysql> Select PlaceID From Place where Latitude =  57.98348 and Longitude = 78.94752;

mysql> Select Partial_Name From Place;

mysql> Select PlaceID From Place where Partial_Name = "SFO";

mysql> Select PlaceID From Place where Latitude = 57.98348 AND Partial_Name = "FK" AND TYPE = "Sea";

mysql> Select PlaceID From Place where Latitude = 57.98348 AND Longitude = 78.94752 AND Partial_Name = "FK" AND TYPE = "Sea" AND Country= "GERMANY";

mysql> Select Latitude, Longitude From Place Where Latitude >= "50" And Latitude <="81" And Longitude >= "40" And Longitude <= "80";

mysql> Select name From Info
    -> Where Language= "Chinese" And DateSupplied = "2000-12-01";

mysql> Select Count(*) From Info Where Language = "Chinese" And DateSupplied >= '2000-12-01' AND DateSupplied <='2000-12-31
';

mysql> Update Employees Set Salary = Salary * 1.1;

mysql> Update Employees Set Bonus = 0;

mysql> Select * from Employees;

mysql> Select Supplier.Name, Supplier.Country, Payement.Date, Count(*)
    -> From Supplier,Payement
    -> Where Supplier.SupplierID=Payement.SupplierID
    -> Group By Name;


